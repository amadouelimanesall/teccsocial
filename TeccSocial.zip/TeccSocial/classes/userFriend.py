class UserFriend:
    def __init__(self, username, friends) -> None:
        self.username = username
        self.friends = friends