# TODO: Enlever le pass et définir la class Post qui contient les 3 attributs suivants:
# username
# content
# postDate
class Post:
    def __init__(self, username,content,postDate) -> None:
        self.username = username
        self.content = content
        self.postDate = postDate