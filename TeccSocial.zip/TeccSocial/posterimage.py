
from PIL import Image
im = Image.open('maphoto.jpg')
im.show()

# autre methode qui permet de selectionner la photo
# #importer le package Image de la bibliothèque Pillow
# from PIL import Image

# #importer la librairie pour la boite de dialogue
# from tkinter.filedialog import askopenfilename

# #récupérer le chemin de l'image via la boite de dialogue
# chemin=askopenfilename(file='Selectionner une image', filetypes=[('JPEG files','.jpg'),('all files','.*')])

# #lire l'image
# imageLue = Image.open(chemin)

# #Afficher l'image
# imageLue.show()